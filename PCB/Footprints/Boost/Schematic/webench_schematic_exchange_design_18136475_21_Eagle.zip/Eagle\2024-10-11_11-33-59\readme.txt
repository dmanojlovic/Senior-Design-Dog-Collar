 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\\CADExport\\workspace\Eagle\2024-10-11_11-33-59\2024-10-11_11-33-59
 
 
To import your new library into Eagle:
1. Start Eagle.
2. In the control panel window, Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************

Besure to check the documentation layer, "48"/"Document", for important information that may seem to be missing or have not translated properly!




For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 
The Symbol WB_LM2735X was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.3.103 Process Report


Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX50Y22D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX45Y73D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX59Y87D0T" Shape(4) is a CIRCLE with no diameter.
Message - Pattern "SLF7045", entity (115-Line) is a LINE with matching start and end points.
Message - Pattern "SLF7045", entity (117-Line) is a LINE with matching start and end points.
Message - Pattern "SLF7045", entity (119-Line) is a LINE with matching start and end points.
Message - Pattern "SLF7045", entity (121-Line) is a LINE with matching start and end points.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".

TextStyle count:  24
Padstack count:   4
Pattern count:    4
Symbol count:     8
Component count:  11

Export

Component "WB_GND" has no mapped footprint will be skipped.
Component "WB_BATTERY" has no mapped footprint will be skipped.
Component "WB_CURRENT_LOAD" has no mapped footprint will be skipped.
